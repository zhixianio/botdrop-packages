#
# Configuration file for using the xslt library
#
XSLT_LIBDIR="-L/data/data/app.botdrop/files/usr/lib"
XSLT_LIBS="-lxslt -lxml2"
XSLT_PRIVATE_LIBS=" -lm"
XSLT_INCLUDEDIR="-I/data/data/app.botdrop/files/usr/include"
MODULE_VERSION="xslt-1.1.45"
