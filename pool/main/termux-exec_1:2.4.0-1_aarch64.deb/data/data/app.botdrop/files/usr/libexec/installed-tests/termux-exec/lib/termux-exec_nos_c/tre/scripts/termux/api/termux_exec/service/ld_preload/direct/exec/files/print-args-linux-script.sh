#!/data/data/app.botdrop/files/usr/bin/sh

echo "$@"
