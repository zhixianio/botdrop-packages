if [ ! -f /data/data/app.botdrop/files/home/.config/termux/termux.properties ] && [ ! -e /data/data/app.botdrop/files/home/.termux/termux.properties ]; then
	mkdir -p /data/data/app.botdrop/files/home/.termux
	cp /data/data/app.botdrop/files/usr/share/examples/termux/termux.properties /data/data/app.botdrop/files/home/.termux/
fi
