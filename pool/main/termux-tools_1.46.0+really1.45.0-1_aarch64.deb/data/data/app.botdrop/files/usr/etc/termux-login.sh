##
## This script is sourced by /data/data/app.botdrop/files/usr/bin/login before executing shell.
##
